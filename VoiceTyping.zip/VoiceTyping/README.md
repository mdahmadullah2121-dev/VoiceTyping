# ভয়েস টাইপিং (Android)

## APK বানানো
1. Android Studio (Koala বা নতুন) ইনস্টল করুন।
2. File > Open > এই VoiceTyping ফোল্ডারটি বেছে নিন। Gradle sync শেষ হতে দিন।
3. ফোন USB দিয়ে লাগিয়ে Run চাপুন, অথবা Build > Build APK(s)।
   APK: app/build/outputs/apk/debug/app-debug.apk

## ফোনে সেটআপ
1. অ্যাপ খুলে মাইক অনুমতি দিন।
2. "চালু করুন" চেপে অ্যাক্সেসিবিলিটিতে "ভয়েস টাইপিং" চালু করুন।
   Android 13+ এ যদি বাটন ধূসর থাকে: Settings > Apps > ভয়েস টাইপিং > ⋮ > Allow restricted settings।
3. Claude API Key বসান (console.anthropic.com থেকে)।
4. ভাষা ও যেসব অ্যাপে বাবল চান তা টিক দিন।
5. সেই অ্যাপ খুলুন: বাবল ভাসবে। বাবল চাপুন, কথা বলুন, আবার চাপলে থামবে।

## কম্পিউটার ছাড়া (GitHub দিয়ে APK)
1. github.com এ বিনামূল্যে একাউন্ট খুলুন, নতুন repository বানান।
2. এই প্রজেক্টের সব ফাইল (লুকানো .github ফোল্ডারসহ) repository তে আপলোড করুন।
3. Actions ট্যাবে "Build APK" চলবে (৫-১০ মিনিট)। শেষ হলে রান খুলে নিচে Artifacts থেকে VoiceTyping-APK ডাউনলোড করুন।
