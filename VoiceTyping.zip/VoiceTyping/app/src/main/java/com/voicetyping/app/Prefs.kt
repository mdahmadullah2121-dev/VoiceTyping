package com.voicetyping.app

import android.content.Context

object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("vt", Context.MODE_PRIVATE)
    fun selected(c: Context): Set<String> = p(c).getStringSet("apps", emptySet()) ?: emptySet()
    fun saveSelected(c: Context, s: Set<String>) = p(c).edit().putStringSet("apps", HashSet(s)).apply()
    fun key(c: Context): String = p(c).getString("key", "") ?: ""
    fun saveKey(c: Context, k: String) = p(c).edit().putString("key", k.trim()).apply()
    fun lang(c: Context): String = p(c).getString("lang", "bn-BD") ?: "bn-BD"
    fun saveLang(c: Context, l: String) = p(c).edit().putString("lang", l).apply()
    fun getInt(c: Context, k: String, d: Int): Int = p(c).getInt(k, d)
    fun putInt(c: Context, k: String, v: Int) = p(c).edit().putInt(k, v).apply()
}
