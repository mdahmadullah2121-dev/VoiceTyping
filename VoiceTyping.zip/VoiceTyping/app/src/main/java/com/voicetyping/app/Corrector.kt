package com.voicetyping.app

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** ভয়েস কমান্ড (দাঁড়ি, কমা...) বদলে চিহ্ন বসায়। */
object Text {
    private val I = RegexOption.IGNORE_CASE
    private val cmds: Map<String, List<Pair<Regex, String>>> = mapOf(
        "bn-BD" to listOf(
            Regex("নতুন লাইন|নিউ লাইন") to "\n",
            Regex("দাঁড়ি|দাড়ি|দাঁড়ী") to "।",
            Regex("প্রশ্ন\\s?চিহ্ন|প্রশ্নবোধক") to "?",
            Regex("কমা") to ",",
            Regex("বিস্ময়\\s?চিহ্ন") to "!"
        ),
        "en-US" to listOf(
            Regex("\\bnew line\\b", I) to "\n",
            Regex("\\bfull stop\\b|\\bperiod\\b", I) to ".",
            Regex("\\bquestion mark\\b", I) to "?",
            Regex("\\bcomma\\b", I) to ",",
            Regex("\\bexclamation (mark|point)\\b", I) to "!"
        ),
        "ar-SA" to listOf(
            Regex("سطر جديد") to "\n",
            Regex("علامة استفهام") to "؟",
            Regex("فاصلة") to "،",
            Regex("نقطة") to ".",
            Regex("علامة تعجب") to "!"
        )
    )

    fun applyCommands(lang: String, t: String): String {
        var s = t
        cmds[lang]?.forEach { (r, v) -> s = s.replace(r, v) }
        s = s.replace(Regex("\\s+([,.?!।،؟])"), "\$1").replace(Regex(" *\\n *"), "\n")
        return s.trim()
    }
}

/** Claude API দিয়ে বানান ও যতিচিহ্ন ঠিক করে। কোনো সমস্যা হলে মূল লেখাই ফেরত দেয়। */
object Corrector {
    private const val MODEL = "claude-haiku-5-5"

    fun fix(apiKey: String, lang: String, text: String): String {
        if (apiKey.isBlank() || text.isBlank()) return text
        val name = when (lang) { "bn-BD" -> "Bangla (Bengali)"; "ar-SA" -> "Arabic"; else -> "English" }
        val prompt = "You are a strict proofreader for voice-typed text in " + name +
            ". The text comes from speech recognition, so fix misheard or wrongly spelled words and all spelling mistakes, " +
            "and add correct punctuation (Bangla: । , ? ! ; English: . , ? ! ; Arabic: ، ؟ .). " +
            "Keep the meaning, do not add new information, keep newlines. Return ONLY the corrected text, no quotes, no explanation.\n\nText:\n" + text
        return try {
            val body = JSONObject()
                .put("model", MODEL)
                .put("max_tokens", 1000)
                .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
            val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 20000
            c.doOutput = true
            c.setRequestProperty("content-type", "application/json")
            c.setRequestProperty("x-api-key", apiKey)
            c.setRequestProperty("anthropic-version", "2023-06-01")
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            if (c.responseCode != 200) return text
            val resp = c.inputStream.bufferedReader().use { it.readText() }
            val out = JSONObject(resp).getJSONArray("content").getJSONObject(0).getString("text").trim()
            if (out.isEmpty()) text else out
        } catch (e: Exception) {
            text
        }
    }
}
