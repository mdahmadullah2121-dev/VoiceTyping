package com.voicetyping.app

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap

private val Green = Color(0xFF0F8F68)
private val Paper = Color(0xFFF6F2E9)
private val Card = Color(0xFFFFFDF8)

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Green, background = Paper, surface = Card)) {
                Screen()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        tick++
    }

    private fun a11yOn(): Boolean {
        val id = ComponentName(this, VoiceService::class.java).flattenToString()
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return s.split(':').any { it.equals(id, ignoreCase = true) }
    }

    @Composable
    private fun Screen() {
        val ctx = this
        val micOk = remember(tick) { checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED }
        val a11yOk = remember(tick) { a11yOn() }
        val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
        var key by remember { mutableStateOf(Prefs.key(ctx)) }
        var lang by remember { mutableStateOf(Prefs.lang(ctx)) }
        var query by remember { mutableStateOf("") }
        val selected = remember { mutableStateListOf<String>().apply { addAll(Prefs.selected(ctx)) } }
        val apps = remember {
            val pm = packageManager
            pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
                .distinctBy { it.first }
                .filter { it.first != packageName }
                .sortedBy { it.second.lowercase() }
        }
        val shown = apps.filter { it.second.contains(query, ignoreCase = true) }

        LazyColumn(
            modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding(),
            contentPadding = PaddingValues(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text("ভয়েস টাইপিং", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Green)
                Text("বলুন, AI ঠিক করে লিখবে", color = Color.Gray)
            }
            item { Step("১. মাইক্রোফোন অনুমতি", micOk, "অনুমতি দিন") { launcher.launch(Manifest.permission.RECORD_AUDIO) } }
            item {
                Step("২. অ্যাক্সেসিবিলিটি সার্ভিস চালু করুন", a11yOk, "চালু করুন") {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
            }
            item {
                OutlinedTextField(
                    value = key,
                    onValueChange = { key = it; Prefs.saveKey(ctx, it) },
                    label = { Text("৩. Claude API Key (বানান ও যতিচিহ্ন ঠিক করার জন্য)") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            item {
                Text("ভাষা", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("bn-BD" to "বাংলা", "en-US" to "English", "ar-SA" to "العربية").forEach { (code, label) ->
                        val on = lang == code
                        val click = { lang = code; Prefs.saveLang(ctx, code) }
                        if (on) Button(onClick = click, shape = RoundedCornerShape(14.dp)) { Text(label) }
                        else OutlinedButton(onClick = click, shape = RoundedCornerShape(14.dp)) { Text(label) }
                    }
                }
            }
            item {
                Text("যেসব অ্যাপে বাবল ভাসবে", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(
                    value = query, onValueChange = { query = it },
                    label = { Text("অ্যাপ খুঁজুন") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
            }
            items(shown, key = { it.first }) { (pkg, label) ->
                val icon = remember(pkg) { packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap() }
                val isOn = pkg in selected
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Card),
                    modifier = Modifier.fillMaxWidth().clickable {
                        if (isOn) selected.remove(pkg) else selected.add(pkg)
                        Prefs.saveSelected(ctx, selected.toSet())
                    }
                ) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Image(icon, contentDescription = null, modifier = Modifier.size(42.dp))
                        Spacer(Modifier.width(14.dp))
                        Text(label, modifier = Modifier.weight(1f), fontSize = 16.sp)
                        Checkbox(checked = isOn, onCheckedChange = null)
                    }
                }
            }
        }
    }

    @Composable
    private fun Step(title: String, done: Boolean, action: String, onClick: () -> Unit) {
        Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Card)) {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(title, fontWeight = FontWeight.Bold)
                    Text(if (done) "✓ সম্পন্ন" else "বাকি আছে", color = if (done) Green else Color.Gray, fontSize = 13.sp)
                }
                if (!done) Button(onClick = onClick, shape = RoundedCornerShape(14.dp)) { Text(action) }
            }
        }
    }
}
