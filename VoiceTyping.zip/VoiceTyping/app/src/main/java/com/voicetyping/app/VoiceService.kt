package com.voicetyping.app

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.PixelFormat
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.InputMethodManager
import android.widget.ImageView
import android.widget.Toast
import java.util.concurrent.Executors
import kotlin.math.abs

class VoiceService : AccessibilityService() {
    private lateinit var wm: WindowManager
    private var bubble: ImageView? = null
    private var params: WindowManager.LayoutParams? = null
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var pulse: ValueAnimator? = null
    private var imePkgs: Set<String> = emptySet()
    private val main = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        imePkgs = (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .enabledInputMethodList.map { it.packageName }.toSet()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) {
            if (event.className?.toString()?.endsWith("MainActivity") == true) hideBubble()
            return
        }
        if (pkg in imePkgs || pkg == "com.android.systemui") return
        if (Prefs.selected(this).contains(pkg)) showBubble() else hideBubble()
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        hideBubble()
        exec.shutdown()
        super.onDestroy()
    }

    // ---------- বাবল ----------
    @SuppressLint("ClickableViewAccessibility")
    private fun showBubble() {
        if (bubble != null) return
        val size = dp(58)
        val v = ImageView(this).apply {
            setPadding(dp(15), dp(15), dp(15), dp(15))
            setBackgroundResource(R.drawable.bubble_idle)
            setImageResource(R.drawable.ic_mic)
            scaleX = 0f; scaleY = 0f
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = Prefs.getInt(this@VoiceService, "bx", resources.displayMetrics.widthPixels - size - dp(6))
            y = Prefs.getInt(this@VoiceService, "by", resources.displayMetrics.heightPixels * 6 / 10)
        }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) + abs(dy) > dp(6)) moved = true
                    if (moved) { lp.x = (ox + dx).toInt(); lp.y = (oy + dy).toInt(); wm.updateViewLayout(v, lp) }
                    true
                }
                MotionEvent.ACTION_UP -> { if (moved) snap(v, lp, size) else toggle(); true }
                else -> false
            }
        }
        try {
            wm.addView(v, lp)
            v.animate().scaleX(1f).scaleY(1f).setDuration(350).setInterpolator(OvershootInterpolator()).start()
            bubble = v; params = lp
        } catch (e: Exception) { toast("বাবল দেখানো যায়নি") }
    }

    private fun snap(v: View, lp: WindowManager.LayoutParams, size: Int) {
        val w = resources.displayMetrics.widthPixels
        val target = if (lp.x + size / 2 < w / 2) dp(6) else w - size - dp(6)
        ValueAnimator.ofInt(lp.x, target).apply {
            duration = 380
            interpolator = OvershootInterpolator()
            addUpdateListener {
                lp.x = it.animatedValue as Int
                try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
            }
        }.start()
        Prefs.putInt(this, "bx", target)
        Prefs.putInt(this, "by", lp.y)
    }

    private fun hideBubble() {
        stopListening()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null; params = null
    }

    private fun setUi(rec: Boolean) {
        val b = bubble ?: return
        b.setBackgroundResource(if (rec) R.drawable.bubble_rec else R.drawable.bubble_idle)
        b.setImageResource(if (rec) R.drawable.ic_stop else R.drawable.ic_mic)
        pulse?.cancel()
        b.scaleX = 1f; b.scaleY = 1f
        if (rec) {
            pulse = ValueAnimator.ofFloat(1f, 1.14f).apply {
                duration = 650
                repeatMode = ValueAnimator.REVERSE
                repeatCount = ValueAnimator.INFINITE
                addUpdateListener { b.scaleX = it.animatedValue as Float; b.scaleY = it.animatedValue as Float }
                start()
            }
        }
    }

    // ---------- ভয়েস ----------
    private fun toggle() { if (listening) stopListening() else startListening() }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toast("আগে অ্যাপ খুলে মাইক্রোফোনের অনুমতি দিন"); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { toast("এই ফোনে ভয়েস রিকগনিশন নেই"); return }
        listening = true
        setUi(true)
        listen()
    }

    private fun stopListening() {
        listening = false
        recognizer?.let { try { it.stopListening(); it.destroy() } catch (_: Exception) {} }
        recognizer = null
        setUi(false)
    }

    private fun listen() {
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
            override fun onError(code: Int) {
                if (!listening) return
                when (code) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                        main.postDelayed({ if (listening) listen() }, 250)
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY ->
                        main.postDelayed({ if (listening) listen() }, 700)
                    else -> { toast("ভয়েস ত্রুটি (" + code + ")"); stopListening() }
                }
            }
            override fun onResults(b: Bundle?) {
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrBlank()) process(t)
                if (listening) main.postDelayed({ if (listening) listen() }, 150)
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Prefs.lang(this))
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        r.startListening(i)
    }

    private fun process(raw: String) {
        val lang = Prefs.lang(this)
        val key = Prefs.key(this)
        val local = Text.applyCommands(lang, raw)
        exec.execute {
            val fixed = Corrector.fix(key, lang, local)
            main.post { insert(fixed) }
        }
    }

    // ---------- লেখার বক্সে বসানো ----------
    private fun copy(text: String) {
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("vt", text))
    }

    private fun insert(text: String) {
        val root = rootInActiveWindow
        val f = root?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (f == null || !f.isEditable) {
            copy(text); toast("লেখার বক্স পাওয়া যায়নি, টেক্সট কপি হয়েছে"); return
        }
        val hint = f.isShowingHintText
        val cur = if (hint) "" else (f.text?.toString() ?: "")
        var s = if (hint) 0 else f.textSelectionStart
        var e = if (hint) 0 else f.textSelectionEnd
        if (s < 0) s = cur.length
        if (e < 0) e = cur.length
        s = s.coerceIn(0, cur.length)
        e = e.coerceIn(s, cur.length)
        val lead = if (s > 0 && !cur[s - 1].isWhitespace() && !text.startsWith("\n")) " " else ""
        val ins = lead + text
        val out = cur.substring(0, s) + ins + cur.substring(e)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, out)
        }
        if (f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
            val caret = s + ins.length
            val sel = Bundle().apply {
                putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, caret)
                putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, caret)
            }
            f.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, sel)
        } else {
            copy(ins)
            if (!f.performAction(AccessibilityNodeInfo.ACTION_PASTE)) toast("টেক্সট কপি হয়েছে, পেস্ট করুন")
        }
    }
}
